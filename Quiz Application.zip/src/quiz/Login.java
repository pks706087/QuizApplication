package quiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login extends JFrame implements ActionListener {

    JButton rule, back;
    JTextField tfname;

    Login() {

        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/login.jpeg"));
        JLabel image = new JLabel(i1);
        image.setBounds(0, 0, 600, 500);
        add(image);

        JLabel heading = new JLabel("Simple Mind");
        heading.setBounds(750, 60, 300, 45);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 35));
        heading.setForeground(new Color(0, 102, 204));
        add(heading);

        JLabel name = new JLabel("Enter Your Name");
        name.setBounds(810, 150, 300, 25);
        name.setFont(new Font("Mongolian Baiti", Font.BOLD, 18));
        name.setForeground(Color.BLUE);
        add(name);

        tfname = new JTextField();
        tfname.setBounds(750, 200, 300, 28);
        tfname.setFont(new Font("Mongolian Baiti", Font.BOLD, 20));
        add(tfname);

        rule = new JButton("Rules");
        rule.setBounds(735, 270, 120, 30);
        rule.setBackground(Color.RED);
        rule.setForeground(Color.WHITE);
        rule.addActionListener(this);
        add(rule);

        back = new JButton("Exit");
        back.setBounds(915, 270, 125, 30);
        back.setBackground(Color.RED);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);

        setSize(1200, 500);
        setLocation(200, 150);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == rule) {
            String name = tfname.getText().trim();

            if (name.equals("")) {
                JOptionPane.showMessageDialog(this, "Please enter your name!");
                return;
            }

            setVisible(false);
            new Rule(name);

        } else if (ae.getSource() == back) {
            System.exit(0);
        }
    }

    public static void main(String args[]) {
        new Login();
    }
}
