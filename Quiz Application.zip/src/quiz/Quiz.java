package quiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Quiz extends JFrame implements ActionListener {

    String questions[][] = new String[10][5];
    String answers[][] = new String[10][2];
    String studentAnswers[] = new String[10];

    JLabel qno, question;
    JRadioButton opt1, opt2, opt3, opt4;
    JButton next, lifeline, submit;

    int count = 0, score = 0;
    boolean lifelineUsed = false;

    ButtonGroup group;  // IMPORTANT: Global ButtonGroup

    Quiz() {

        setBounds(50, 0, 1440, 850);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/quiz.jpg"));
        JLabel image = new JLabel(i1);
        image.setBounds(0, 0, 1440, 390);
        add(image);

        qno = new JLabel();
        qno.setBounds(100, 450, 50, 30);
        qno.setFont(new Font("Tahoma", Font.PLAIN, 24));
        add(qno);

        question = new JLabel();
        question.setBounds(200, 450, 970, 30);
        question.setFont(new Font("Tahoma", Font.PLAIN, 24));
        add(question);

        opt1 = new JRadioButton();
        opt1.setBounds(170, 520, 700, 30);
        opt1.setBackground(Color.white);
        opt1.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt1);

        opt2 = new JRadioButton();
        opt2.setBounds(170, 560, 700, 30);
        opt2.setBackground(Color.white);
        opt2.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt2);

        opt3 = new JRadioButton();
        opt3.setBounds(170, 600, 700, 30);
        opt3.setBackground(Color.white);
        opt3.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt3);

        opt4 = new JRadioButton();
        opt4.setBounds(170, 640, 700, 30);
        opt4.setBackground(Color.white);
        opt4.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt4);

        // FIX: Only one ButtonGroup, defined once
        group = new ButtonGroup();
        group.add(opt1);
        group.add(opt2);
        group.add(opt3);
        group.add(opt4);

        next = new JButton("Next");
        next.setBounds(1100, 550, 200, 40);
        next.addActionListener(this);
        add(next);

        lifeline = new JButton("50-50 Lifeline");
        lifeline.setBounds(1100, 630, 200, 40);
        lifeline.addActionListener(this);
        add(lifeline);

        submit = new JButton("Submit");
        submit.setBounds(1100, 710, 200, 40);
        submit.setEnabled(false);
        submit.addActionListener(this);
        add(submit);

        loadQuestions();
        start(count);

        setVisible(true);
    }

    void loadQuestions() {
        questions[0][0] = "Which is used to find and fix bugs in Java programs?";
        questions[0][1] = "JVM";      questions[0][2] = "JDB";
        questions[0][3] = "JDK";      questions[0][4] = "JRE";

        answers[0][1] = "JDB";

        questions[1][0] = "What is return type of hashCode()?";
        questions[1][1] = "int";      questions[1][2] = "Object";
        questions[1][3] = "long";     questions[1][4] = "void";

        answers[1][1] = "int";

        questions[2][0] = "Which package contains Random class?";
        questions[2][1] = "java.util package";  questions[2][2] = "java.lang package";
        questions[2][3] = "java.awt package";   questions[2][4] = "java.io package";

        answers[2][1] = "java.util package";

        questions[3][0] = "Interface with no methods is?";
        questions[3][1] = "Runnable";  questions[3][2] = "Abstract";
        questions[3][3] = "Marker";    questions[3][4] = "CharSequence";

        answers[3][1] = "Marker";

        questions[4][0] = "Where is String stored using new?";
        questions[4][1] = "Stack"; questions[4][2] = "String Memory";
        questions[4][3] = "Random"; questions[4][4] = "Heap memory";

        answers[4][1] = "Heap memory";

        questions[5][0] = "Marker interface?";
        questions[5][1] = "Runnable"; questions[5][2] = "Remote";
        questions[5][3] = "Readable"; questions[5][4] = "Result";

        answers[5][1] = "Remote";

        questions[6][0] = "Keyword for accessing package?";
        questions[6][1] = "import"; questions[6][2] = "package";
        questions[6][3] = "extends"; questions[6][4] = "export";

        answers[6][1] = "import";

        questions[7][0] = "JAR stands for?";
        questions[7][1] = "Java Archive Runner"; questions[7][2] = "Java Archive";
        questions[7][3] = "Java Resource";       questions[7][4] = "Java App Runner";

        answers[7][1] = "Java Archive";

        questions[8][0] = "Mutable class?";
        questions[8][1] = "StringBuilder"; questions[8][2] = "Short";
        questions[8][3] = "Byte";           questions[8][4] = "String";

        answers[8][1] = "StringBuilder";

        questions[9][0] = "Portability of Java is due to?";
        questions[9][1] = "Bytecode executed by JVM"; questions[9][2] = "Applet";
        questions[9][3] = "Exception";              questions[9][4] = "Dynamic binding";

        answers[9][1] = "Bytecode executed by JVM";
    }

    public void start(int count) {

        group.clearSelection();  // FIX: Allows selecting new option every time

        qno.setText((count + 1) + ". ");
        question.setText(questions[count][0]);

        opt1.setText(questions[count][1]);
        opt2.setText(questions[count][2]);
        opt3.setText(questions[count][3]);
        opt4.setText(questions[count][4]);

        opt1.setEnabled(true);
        opt2.setEnabled(true);
        opt3.setEnabled(true);
        opt4.setEnabled(true);
    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == next) {

            saveAnswer();

            count++;

            if (count == 9) {
                next.setEnabled(false);
                submit.setEnabled(true);
            }

            start(count);
        }

        else if (ae.getSource() == lifeline) {
            if (!lifelineUsed) {
                lifelineUsed = true;

                String correct = answers[count][1];
                int disabled = 0;

                if (!opt1.getText().equals(correct) && disabled < 2) { opt1.setEnabled(false); disabled++; }
                if (!opt2.getText().equals(correct) && disabled < 2) { opt2.setEnabled(false); disabled++; }
                if (!opt3.getText().equals(correct) && disabled < 2) { opt3.setEnabled(false); disabled++; }
                if (!opt4.getText().equals(correct) && disabled < 2) { opt4.setEnabled(false); disabled++; }

                lifeline.setEnabled(false);
            }
        }

        else if (ae.getSource() == submit) {

            saveAnswer();

            for (int i = 0; i < 10; i++) {
                if (studentAnswers[i].equals(answers[i][1])) score += 10;
            }

            setVisible(false);
            new Score("User", score);
        }
    }

    void saveAnswer() {
        if (opt1.isSelected()) studentAnswers[count] = opt1.getText();
        else if (opt2.isSelected()) studentAnswers[count] = opt2.getText();
        else if (opt3.isSelected()) studentAnswers[count] = opt3.getText();
        else if (opt4.isSelected()) studentAnswers[count] = opt4.getText();
        else studentAnswers[count] = "";
    }

    public static void main(String args[]) {
        new Quiz();
    }
}
