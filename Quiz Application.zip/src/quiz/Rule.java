package quiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Rule extends JFrame implements ActionListener {

    String name;
    JButton start, back;

    Rule(String name) {

        this.name = name;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("Welcome " + name + " to Simple Mind");
        heading.setBounds(50, 20, 700, 40);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 35));
        heading.setForeground(Color.BLUE);
        add(heading);

        JTextArea rule = new JTextArea();
        rule.setBounds(20, 90, 700, 350);
        rule.setFont(new Font("Tahoma", Font.PLAIN, 15));
        rule.setText(
                "1. Answer point to point.\n\n"
                + "2. Do not smile unnecessarily.\n\n"
                + "3. All questions are compulsory.\n\n"
                + "4. Crying allowed, but quietly.\n\n"
                + "5. Be wise.\n\n"
                + "6. Don’t get nervous.\n\n"
                + "7. Brace yourself.\n\n"
                + "8. Good Luck!"
        );
        rule.setEditable(false);
        rule.setLineWrap(true);
        rule.setWrapStyleWord(true);

        JScrollPane scroll = new JScrollPane(rule);
        scroll.setBounds(20, 90, 740, 350);
        add(scroll);

        start = new JButton("Start");
        start.setBounds(400, 500, 120, 35);
        start.setBackground(Color.RED);
        start.setForeground(Color.WHITE);
        start.addActionListener(this);
        add(start);

        back = new JButton("Back");
        back.setBounds(250, 500, 120, 35);
        back.setBackground(Color.RED);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);

        setSize(800, 650);
        setLocation(350, 100);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == start) {
            setVisible(false);
            new Quiz();
        } else {
            setVisible(false);
            new Login();
        }
    }

    public static void main(String args[]) {
        new Rule("User");
    }
}
